from django.apps import AppConfig
import os
from index.apps import *

#s设置应用名字中文显示->apps.py
default_app_config='index.IndexConfig'